"use client";

import { FormEvent, useState } from "react";

const membershipTypes = ["መደበኛ", "መስራች", "ቋሚ", "ተባባሪ", "ሌላ"];

export default function Home() {
  const [stage, setStage] = useState<"form" | "verify" | "success">("form");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [membershipType, setMembershipType] = useState("መደበኛ");
  const [otp, setOtp] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  async function requestCode(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setNotice("");
    setBusy(true);
    try {
      const response = await fetch("/api/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), fullName: fullName.trim() }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "ኮዱን መላክ አልተቻለም።");
      setStage("verify");
      setNotice("የማረጋገጫ ኮድ ወደ ኢሜይልዎ ተልኳል። የSpam/Junk ክፍሉንም ይመልከቱ።");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "ስህተት ተፈጥሯል።");
    } finally {
      setBusy(false);
    }
  }

  async function finishRegistration(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setNotice("");
    setBusy(true);
    try {
      const response = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: fullName.trim(),
          email: email.trim(),
          phone: phone.trim(),
          membershipType,
          otp: otp.trim(),
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "ምዝገባው አልተሳካም።");
      setStage("success");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "ስህተት ተፈጥሯል።");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main>
      <header className="topbar">
        <a className="brand" href="#home" aria-label="ዋና ገጽ">
          <span className="brand-mark">✦</span>
          <span><strong>መሠረተ አንድነት</strong><small>በጎ አድራጎት ማህበር</small></span>
        </a>
        <nav><a href="#about">ስለ ማህበሩ</a><a href="#rules">ደንብ</a><a className="nav-cta" href="#join">አባል ይሁኑ</a></nav>
      </header>

      <section className="hero" id="home">
        <div className="hero-content">
          <p className="eyebrow">በአንድነት ለበጎ ዓላማ</p>
          <h1>ትንሽ የደግነት ተግባር፣<br /><span>ትልቅ የለውጥ መሠረት።</span></h1>
          <p className="hero-copy">እጅ ለእጅ ተያይዘን የምንችለውን በማድረግ፣ ተስፋን እንዘራ፤ የሰው ልጅን ክብር እና መልካምነትን እናጠናክር።</p>
          <div className="hero-actions"><a className="button button-primary" href="#join">አባል ለመሆን ይመዝገቡ <span>↗</span></a><a className="text-link" href="#about">ስለ ማህበሩ ይወቁ ↓</a></div>
          <div className="hero-note"><span className="dot" /> በአንድነት የምንፈጥረው ተስፋ</div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="sun"></div><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div>
          <div className="hands">♡</div><div className="art-label label-top">ደግነት</div><div className="art-label label-bottom">አንድነት · ተስፋ · እርዳታ</div>
        </div>
      </section>

      <section className="values" id="about">
        <div><span className="value-icon">♡</span><h3>ደግነት</h3><p>ለሌሎች በርኅራኄ መቆምና የሚቻለውን ድጋፍ ማድረግ።</p></div>
        <div><span className="value-icon">✧</span><h3>አንድነት</h3><p>በመተባበር የጋራ ዓላማችንን ወደ ተግባር መቀየር።</p></div>
        <div><span className="value-icon">↗</span><h3>ተስፋ</h3><p>በተግባር የሚታይ ለውጥን በታማኝነት መገንባት።</p></div>
      </section>

      <section className="join-section" id="join">
        <div className="section-intro">
          <p className="eyebrow">ከእኛ ጋር ይቀላቀሉ</p>
          <h2>መልካምነትን<br /><span>አብረን እናስፋፋ።</span></h2>
          <p>የአባልነት ምዝገባውን ይሙሉ። በኢሜይልዎ የሚላክልዎን የማረጋገጫ ኮድ ካስገቡ በኋላ ምዝገባዎ ይጠናቀቃል።</p>
          <div className="chair-card"><div className="avatar">ደ</div><div><small>መስራች እና ሰብሳቢ</small><strong>ደሳለኝ ጌታቸው</strong></div></div>
        </div>

        <div className="form-card">
          {stage === "success" ? (
            <div className="success-state"><div className="success-icon">✓</div><h2>እንኳን ደስ አለዎት!</h2><p>የአባልነት ምዝገባዎ በተሳካ ሁኔታ ተጠናቋል።</p><p className="muted">ስለ ማህበሩ አባል ለመሆን ስለመረጡ እናመሰግናለን።</p></div>
          ) : stage === "form" ? (
            <>
              <div className="form-heading"><span className="step">01 / 02</span><h2>የአባልነት ምዝገባ</h2><p>መረጃዎን ከታች ያስገቡ።</p></div>
              <form onSubmit={requestCode}>
                <label>ሙሉ ስም<input required value={fullName} onChange={e => setFullName(e.target.value)} placeholder="ሙሉ ስምዎን ያስገቡ" minLength={2} maxLength={100} /></label>
                <label>ኢሜይል አድራሻ<input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" maxLength={254} /></label>
                <button className="button button-primary full-width" disabled={busy}>{busy ? "በመላክ ላይ..." : "የማረጋገጫ ኮድ ላክ"} <span>→</span></button>
              </form>
            </>
          ) : (
            <>
              <div className="form-heading"><span className="step">02 / 02</span><h2>ምዝገባውን ያጠናቅቁ</h2><p><strong>{email}</strong> ላይ የተላከውን 6 አሃዝ ኮድ ያስገቡ።</p></div>
              <form onSubmit={finishRegistration}>
                <label>የማረጋገጫ ኮድ<input required inputMode="numeric" autoComplete="one-time-code" value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="123456" pattern="[0-9]{6}" minLength={6} maxLength={6} /></label>
                <label>ስልክ ቁጥር<input required type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+251..." maxLength={30} /></label>
                <label>የአባልነት አይነት<select value={membershipType} onChange={e => setMembershipType(e.target.value)}>{membershipTypes.map(type => <option key={type}>{type}</option>)}</select></label>
                <button className="button button-primary full-width" disabled={busy}>{busy ? "በማረጋገጥ ላይ..." : "ምዝገባውን አጠናቅቅ"} <span>✓</span></button>
                <button className="back-button" type="button" onClick={() => { setStage("form"); setNotice(""); }}>← ወደ ቀደመው ገጽ ተመለስ</button>
              </form>
            </>
          )}
          {notice && <p className={notice.includes("ተልኳል") ? "notice success-notice" : "notice"} role="status">{notice}</p>}
          <p className="privacy-note">🔒 የግል መረጃዎ ለምዝገባ እና ለማህበሩ አስተዳደራዊ ግንኙነት ብቻ ይጠቀማል።</p>
        </div>
      </section>

      <section className="rules-section" id="rules">
        <div className="rules-heading"><p className="eyebrow">ግልጽነት · ተጠያቂነት</p><h2>የውስጥ ሕግና ደንብ</h2><p>የማህበሩ አባላት በጋራ የሚከተሉት መርሆዎች።</p></div>
        <div className="rules-grid">
          <article><span>01</span><h3>ስምና ዓላማ</h3><p>ማህበሩ በ“መሠረተ አንድነት በጎ አድራጎት ማህበር” ስም የሚታወቅ ሲሆን የበጎ አድራጎትን፣ የሰብአዊ ድጋፍንና የማህበረሰብ ትብብርን ማጠናከር ዓላማው ነው።</p></article>
          <article><span>02</span><h3>የአባላት መብት</h3><p>አባላት በማህበሩ ተግባራት መሳተፍ፣ ሃሳብ ማቅረብ፣ በሕጉ መሠረት መምረጥና መመረጥ ይችላሉ።</p></article>
          <article><span>03</span><h3>የአባላት ግዴታ</h3><p>አባላት የማህበሩን ዓላማና ደንብ ማክበር፣ በታማኝነት መሳተፍና የሌሎችን ክብር ማክበር አለባቸው።</p></article>
          <article><span>04</span><h3>ገንዘብና ግልጽነት</h3><p>የማህበሩ ገቢና ወጪ በተመዘገበ መንገድ ይተዳደራል። ሪፖርትና ቁጥጥር በማህበሩ የተፈቀደ አሠራር ይከናወናል።</p></article>
          <article><span>05</span><h3>አመራርና ስብሰባ</h3><p>የአመራር ኃላፊነት፣ የስብሰባ ጥሪ፣ የውሳኔ አሰጣጥና የምርጫ ሂደት በተፈቀደው የማህበሩ ደንብ ይመራሉ።</p></article>
          <article><span>06</span><h3>ሥነ-ምግባርና ቅሬታ</h3><p>አድልዎ፣ ጥቅም ግጭትና የማህበሩን ሀብት በግል ጥቅም መጠቀም አይፈቀድም። ቅሬታዎች በፍትሃዊና ግልጽ ሂደት ይመረመራሉ።</p></article>
        </div>
        <div className="draft-note"><strong>ማስታወሻ፦</strong> ከላይ ያለው የደንብ ክፍል ረቂቅ ነው። ማህበሩ ከመጠቀሙ በፊት በመስራች አባላት መገምገምና እንደ ማህበሩ ሕጋዊ ሁኔታ እና ተፈጻሚ ሕግ መሠረት መፅደቅ አለበት።</div>
      </section>

      <footer><a className="brand footer-brand" href="#home"><span className="brand-mark">✦</span><span><strong>መሠረተ አንድነት</strong><small>በጎ አድራጎት ማህበር</small></span></a><p>በአንድነት የምንገነባው ተስፋ።</p><small>© {new Date().getFullYear()} መሠረተ አንድነት በጎ አድራጎት ማህበር</small></footer>
    </main>
  );
}
