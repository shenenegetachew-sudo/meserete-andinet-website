import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "መሠረተ አንድነት | በጎ አድራጎት ማህበር",
  description: "በአንድነት በጎ ሥራን እናበረታታ፤ የአባልነት ምዝገባ።",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="am">
      <body>{children}</body>
    </html>
  );
}
