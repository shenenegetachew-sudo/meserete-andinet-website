import { createHash, timingSafeEqual } from "node:crypto";
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getEmailFrom, getResend } from "@/lib/email";

export const runtime = "nodejs";

function hashCode(email: string, code: string) {
  return createHash("sha256").update(`${email.toLowerCase()}:${code}:${process.env.OTP_PEPPER || "change-this-in-production"}`).digest("hex");
}
function safeEqual(a: string, b: string) {
  const aa = Buffer.from(a, "hex");
  const bb = Buffer.from(b, "hex");
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}
function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char] || char));
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const fullName = typeof body.fullName === "string" ? body.fullName.trim() : "";
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const phone = typeof body.phone === "string" ? body.phone.trim() : "";
    const membershipType = typeof body.membershipType === "string" ? body.membershipType : "";
    const otp = typeof body.otp === "string" ? body.otp.trim() : "";
    const allowedTypes = ["መደበኛ", "መስራች", "ቋሚ", "ተባባሪ", "ሌላ"];

    if (fullName.length < 2 || fullName.length > 100) return NextResponse.json({ error: "ሙሉ ስምዎን በትክክል ያስገቡ።" }, { status: 400 });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return NextResponse.json({ error: "ትክክለኛ ኢሜይል ያስገቡ።" }, { status: 400 });
    if (phone.length < 7 || phone.length > 30) return NextResponse.json({ error: "ትክክለኛ ስልክ ቁጥር ያስገቡ።" }, { status: 400 });
    if (!allowedTypes.includes(membershipType)) return NextResponse.json({ error: "የአባልነት አይነት ይምረጡ።" }, { status: 400 });
    if (!/^\d{6}$/.test(otp)) return NextResponse.json({ error: "የ6 አሃዝ ማረጋገጫ ኮድ ያስገቡ።" }, { status: 400 });

    const verification = await prisma.otpVerification.findUnique({ where: { email } });
    if (!verification) return NextResponse.json({ error: "የማረጋገጫ ኮድ አልተገኘም። አዲስ ኮድ ይጠይቁ።" }, { status: 400 });
    if (verification.expiresAt.getTime() < Date.now()) {
      await prisma.otpVerification.delete({ where: { email } }).catch(() => undefined);
      return NextResponse.json({ error: "ኮዱ ጊዜው አልፎበታል። አዲስ ኮድ ይጠይቁ።" }, { status: 400 });
    }
    if (verification.attempts >= 5) {
      await prisma.otpVerification.delete({ where: { email } }).catch(() => undefined);
      return NextResponse.json({ error: "ብዙ ጊዜ ስለሞከሩ አዲስ ኮድ ይጠይቁ።" }, { status: 429 });
    }
    const expected = hashCode(email, otp);
    if (!safeEqual(verification.codeHash, expected)) {
      await prisma.otpVerification.update({ where: { email }, data: { attempts: { increment: 1 } } });
      return NextResponse.json({ error: "የማረጋገጫ ኮዱ ትክክል አይደለም።" }, { status: 400 });
    }

    const member = await prisma.member.create({ data: { fullName, email, phone, membershipType } });
    await prisma.otpVerification.delete({ where: { email } }).catch(() => undefined);

    // Registration remains successful even if the admin notification email has a temporary problem.
    try {
      const adminEmail = process.env.ADMIN_EMAIL || "mesereteandinetdilla@gmail.com";
      const resend = getResend();
      const sent = await resend.emails.send({
        from: getEmailFrom(),
        to: [adminEmail],
        subject: "አዲስ የአባልነት ምዝገባ - መሠረተ አንድነት",
        html: `<div style="font-family:Arial,sans-serif;max-width:600px;color:#173b32"><h2>አዲስ አባል ተመዝግቧል</h2><p><b>ሙሉ ስም:</b> ${escapeHtml(member.fullName)}</p><p><b>ኢሜይል:</b> ${escapeHtml(member.email)}</p><p><b>ስልክ:</b> ${escapeHtml(member.phone)}</p><p><b>የአባልነት አይነት:</b> ${escapeHtml(member.membershipType)}</p><p><b>የተመዘገበበት ጊዜ:</b> ${member.createdAt.toISOString()}</p></div>`,
      });
      if (sent.error) console.error("Admin notification error:", sent.error);
    } catch (mailError) {
      console.error("Admin notification error:", mailError);
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("register error:", error);
    if (typeof error === "object" && error !== null && "code" in error && error.code === "P2002") {
      return NextResponse.json({ error: "ይህ ኢሜይል አስቀድሞ ተመዝግቧል።" }, { status: 409 });
    }
    return NextResponse.json({ error: "ምዝገባውን ማጠናቀቅ አልተቻለም። እባክዎ በኋላ ይሞክሩ።" }, { status: 500 });
  }
}
